# APU — Automatic Polling Utility

An Agent Zero v1.2 plugin that enforces non-blocking cooldown delays between
tool executions to prevent API rate exhaustion and reduce token waste.

## Features

- Automatic delay after every tool execution (configurable, 0–600 seconds)
- High-compute detection: multiplies delay for tools matching resource-heavy
  patterns (`api`, `fetch`, `download`, `scrape`, `crawl`, `stream`) or tasks
  running longer than 5 seconds
- Minimum cooldown floor to guarantee a baseline rate limit
- Non-blocking implementation (`asyncio.sleep`) — agent stays responsive
- Cooldown state persisted to disk (`cooldown_state.json`) — survives restarts
- **Wake APU** button in the chat UI to interrupt an active cooldown instantly
- Config panel with sliders + number inputs for all settings

## Configuration

| Setting | Default | Description |
|---|---|---|
| `apu_enabled` | `true` | Enable/disable the plugin entirely |
| `base_wait_seconds` | `300` | Base delay after every tool call (0–600s) |
| `high_compute_multiplier` | `1.75` | Multiplier applied to high-resource tools |
| `min_api_cooldown` | `60` | Minimum delay floor in seconds |

## How It Works

1. After each tool execution, the `tool_execute_after` extension hook fires
2. APU checks for high-compute patterns or long runtimes (>5s)
3. Calculates final delay: `base_wait * multiplier`, clamped to `[min_cooldown, 3600]`
4. Stores the cooldown expiry timestamp to memory and disk
5. Sleeps non-blocking for the calculated duration

The **Wake APU** button (lightning bolt in the chat input bar) calls
`POST /plugins/apu_governor/apu_wake` to clear the cooldown immediately.

## Installation

Drop the `apu_governor/` folder into `/a0/usr/plugins/` and enable it from
the Agent Zero plugin list. No external dependencies required.

## Plugin Structure

```
apu_governor/
├── plugin.yaml
├── default_config.yaml
├── README.md
├── LICENSE
├── api/
│   └── apu_wake.py              # Wake endpoint — clears cooldown immediately
├── extensions/
│   ├── python/
│   │   └── tool_execute_after/
│   │       └── _50_apu_governor.py  # Core cooldown logic
│   └── webui/
│       └── chat-input-bottom-actions-end/
│           └── apu-wake-button.html # Wake APU button in chat bar
├── lib/
│   └── state.py                 # Shared cooldown store with disk persistence
├── tools/
│   └── apu_sleep.py             # Agent-controlled cooldown tool
└── webui/
    ├── config.html              # Settings UI with sliders
    └── thumbnail.png
```

## License

```
MIT License

Copyright (c) 2026 MrTrench / CONTAK

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
